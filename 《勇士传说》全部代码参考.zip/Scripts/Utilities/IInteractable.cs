

public interface IInteractable
{
    void TriggerAction();
}

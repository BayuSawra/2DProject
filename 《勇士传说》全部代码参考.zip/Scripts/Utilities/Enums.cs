public enum NPCState
{
    Patrol, Chase, Skill
}

public enum SceneType
{
    Loaction, Menu
}

public enum PersistentType
{
    ReadWrite, DoNotPersist
}